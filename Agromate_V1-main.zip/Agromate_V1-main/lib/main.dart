import 'package:Agromate/pages/add_user.dart';
import 'package:Agromate/pages/change_pwd.dart';
import 'package:Agromate/pages/del_user.dart';
import 'package:Agromate/pages/mode_page.dart';
import 'package:Agromate/pages/new_home_page.dart';
import 'package:Agromate/pages/phone_number.dart';
import 'package:Agromate/pages/splash_screen.dart';
import 'package:Agromate/pages/users_page.dart';
import 'package:Agromate/pages/schedule_page.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/pages/settings_page.dart';
import 'package:Agromate/pages/home_page.dart';
import 'package:Agromate/pages/status_page.dart';
import 'package:Agromate/pages/about_page.dart';
import 'package:Agromate/Values/app_routes.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:Agromate/pages/logs_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Agromate Home',
      theme: AppTheme().myTheme,
      initialRoute: AppRoutes.splashPage,
      routes: {
        AppRoutes.homePage: (context) => const HomePage(),
        AppRoutes.settingsPage: (context) => const SettingsPage(),
        AppRoutes.statusPage: (context) => const StatusPage(stat: 'N/A'),
        AppRoutes.aboutPage: (context) => const AboutPage(),
        AppRoutes.logsPage: (context) => const LogsPage(),
        AppRoutes.schedulePage: (context) => const SchedulePage(),
        AppRoutes.users: (context) => const Users(),
        AppRoutes.addUser: (context) => const AddUser(),
        AppRoutes.deleteUser: (context) => const DeleteUser(),
        AppRoutes.mode: (context) => const Mode(),
        AppRoutes.changePass: (context) => const ChangePass(),
        AppRoutes.phoneNum: (context) => const PhoneNum(),
        AppRoutes.splashPage: (context) => const SplashPage(),
        AppRoutes.newHome: (context) => const NewHome(),
      },
    );
  }
}
