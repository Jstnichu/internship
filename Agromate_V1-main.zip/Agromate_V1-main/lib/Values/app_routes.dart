class AppRoutes {
  static const String homePage = '/homePage';
  static const String settingsPage = '/SettingsPage';
  static const String statusPage = '/StatusPage';
  static const String aboutPage = '/AboutPage';
  static const String logsPage = '/LogsPage';
  static const String schedulePage = '/SchedulePage';
  static const String users = '/Users';
  static const String addUser = '/AddUser';
  static const String deleteUser = '/DeleteUser';
  static const String mode = '/Mode';
  static const String changePass = '/ChangePass';
  static const String phoneNum = '/phoneNum';
  static const String splashPage = '/splashPage';
  static const String newHome = '/newHome';
}
