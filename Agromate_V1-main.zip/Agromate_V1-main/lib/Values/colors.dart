import 'package:flutter/material.dart';

class AllColor {
  Color txtColor = const Color.fromARGB(255, 0, 72, 4);
}
