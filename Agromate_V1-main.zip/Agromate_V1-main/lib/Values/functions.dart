import 'dart:async';

import 'package:Agromate/Values/app_routes.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:Agromate/Values/colors.dart';
// import 'package:Agromate/pages/logs_page.dart';
// import 'package:Agromate/pages/new_home_page.dart';
// import 'package:Agromate/pages/schedule_page.dart';
// import 'package:Agromate/pages/settings_page.dart';
import 'package:Agromate/pages/status_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:telephony/telephony.dart';

List<String> contacts = [];
ThemeData myTheme = AppTheme().myTheme;
Telephony telephony = Telephony.instance;
String? phoneNum;
Future<void> savePhoneNumber(
    String phoneNumber, BuildContext context, String phone) async {
  SharedPreferences preferences = await SharedPreferences.getInstance();
  await preferences.setString('phoneNumber', phoneNumber);
  contacts.clear();
  contacts.insert(0, phoneNumber);
  await Navigator.pushNamed(context, AppRoutes.homePage);
}

getPhoneNumber(BuildContext context) async {
  SharedPreferences preferences = await SharedPreferences.getInstance();
  phoneNum = preferences.getString('phoneNumber');
  if (phoneNum == null) {
    Navigator.pushNamed(context, AppRoutes.phoneNum);
    // AppRoutes.phoneNum;
  } else if (phoneNum != null) {
    // contacts = [];
    contacts.clear();
    contacts.insert(0, phoneNum!);
    Navigator.pushNamed(context, AppRoutes.newHome);

    // contacts.add(phoneNum!);
  }
}

ElevatedButton buildElevatedButton(
    String buttonText, String buttonAction, BuildContext context,
    [Function? callback]) {
  return ElevatedButton(
    onPressed: () {
      if (buttonAction == "setting") {
        Navigator.pushNamed(
          context,
          AppRoutes.settingsPage,
        );
      } else if (buttonAction == "status") {
        showPopup(context, "Getting Status", true, 0);
        SendSMS('MOTOR STATUS', contacts, context);
      } else if (buttonAction == "about") {
        Navigator.pushNamed(
          context,
          AppRoutes.aboutPage,
        );
      } else if (buttonAction == "on") {
        showPopup(context, "Motor Turning ON", true, 0);
        SendSMS('MOTOR ON', contacts, context);
      } else if (buttonAction == "off") {
        showPopup(context, "Motor Turning OFF", true, 0);
        SendSMS('MOTOR OFF', contacts, context);
      }
      if (buttonAction == "schedule") {
        Navigator.pushNamed(context, AppRoutes.schedulePage);
      } else if (buttonAction == "back") {
        Navigator.pop(context);
      } else if (buttonAction == "addDevice") {
      } else if (buttonAction == "user") {
        Navigator.pushNamed(context, AppRoutes.users);
      } else if (buttonAction == "logs") {
        Navigator.pushNamed(context, AppRoutes.logsPage);
      }
      if (buttonAction == "fetchUsers") {
        showPopup(context, "Fetching Users", true, 0);
        SendSMS('USERS', contacts, context);
      } else if (buttonAction == "Users") {
        Navigator.pushNamed(context, AppRoutes.addUser);
      } else if (buttonAction == "DeleteUser") {
        Navigator.pushNamed(context, AppRoutes.deleteUser);
      } else if (buttonAction == 'registerUser') {
        callback!();
      } else if (buttonAction == 'Mode') {
        Navigator.pushNamed(context, AppRoutes.mode);
      } else if (buttonAction == 'smartMode') {
        showPopup(context, 'Setting Device to Intelligent Mode.', true, 0);
        SendSMS("Mode I", contacts, context);
      } else if (buttonAction == 'autoMode') {
        showPopup(context, 'Setting Device to Auto Mode.', true, 0);
        SendSMS("Mode A", contacts, context);
      } else if (buttonAction == 'idleMode') {
        showPopup(context, 'Setting Device to Idle Mode.', true, 0);
        SendSMS("Mode L", contacts, context);
      } else if (buttonAction == 'changePwd') {
        Navigator.pushNamed(context, AppRoutes.changePass);
      } else if (buttonAction == 'phoneNum') {
        Navigator.pushNamed(context, AppRoutes.phoneNum);
      } else if (buttonAction == 'next') {
        callback!();
      }
    },
    style: ElevatedButton.styleFrom(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      backgroundColor: myTheme.colorScheme.primaryContainer,
      fixedSize: const Size(300.0, 60.0),
      padding: const EdgeInsets.all(12.0),
    ),
    child: Text(
      buttonText,
      style: TextStyle(
        fontSize: 25,
        fontWeight: FontWeight.bold,
        color: AllColor().txtColor,
      ),
    ),
  );
}

// ignore: non_constant_identifier_names
void SendSMS(String msg, List<String> recipients, BuildContext context) async {
  try {
    var status = await Permission.sms.status;
    if (status.isDenied) {
      await Permission.sms.request();
    }
    await sendSMS(
      message: msg,
      recipients: recipients,
      sendDirect: true,
    );

    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        incoming(message.body, context, msg);
      },
      listenInBackground: false,
    );
  } catch (onError) {
    // ignore: use_build_context_synchronously
    showPopup(context, "There was an error sending SMS. check app permissions.",
        false, 0);
  }
}

void showPopup(BuildContext context, String text, bool loading, int time) {
  if (loading) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(text),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  } else if (loading == false) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(text),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
          ),
        );
      },
    );
  }
  if (time != 0) {
    Future.delayed(Duration(seconds: time), () {
      if (Navigator.canPop(context)) {
        Navigator.of(context, rootNavigator: true).pop();
      }
    });
  }
}

void incoming(String? msg, BuildContext context, String sent) {
  String? instr = msg?.split(":").first.trim();
  String? up = msg?.split(":").last.trim();
  String userData = up.toString();
  String newString = instr.toString();
  int parsedValue = int.parse(newString);
  String? time =
      RegExp(r'\d{1,2}:\d{1,2}').firstMatch(msg.toString())?.group(0);
  List<String>? parts = time?.split(":");
  String? hrs = parts?[0];
  String? mins = parts?[1];
  if (parsedValue == 1) {
    pop(context);

    showPopup(context, "Motor is ON ✅", false, 3);
  } else if (parsedValue == 3) {
    pop(context);
    showPopup(context, "Motor is already ON", false, 4);
  } else if (parsedValue == 4) {
    pop(context);
    showPopup(context, "Motor is already OFF", false, 4);
  } else if (parsedValue == 5) {
    pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => StatusPage(stat: "ON for $time")),
    );
  } else if (parsedValue == 6) {
    pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const StatusPage(stat: "OFF"),
      ),
    );
  } else if (parsedValue == 7) {
    pop(context);
    showPopup(context,
        "Motor is OFF. It ran for $hrs Hours and $mins Minutes ✅", false, 5);
  } else if (parsedValue == 57) {
    pop(context);
    showPopup(context, userData, false, 7);
  } else if (parsedValue == 60) {
    pop(context);
    showPopup(context, "The user has already been registered.", false, 7);
  } else if (parsedValue == 62) {
    pop(context);
    showPopup(context, "The Password is Incorrect.", false, 7);
  } else if (parsedValue == 52) {
    pop(context);
    showPopup(context, "Successfully registered ✅", false, 7);
  } else if (parsedValue == 59) {
    pop(context);
    showPopup(context, "Successfully Deleted ✅", false, 7);
  } else if (parsedValue == 53) {
    pop(context);
    showPopup(context, "Device is set to Intelligent Mode ✅", false, 7);
  } else if (parsedValue == 54) {
    pop(context);
    showPopup(context, "Device is set to Auto Mode ✅", false, 7);
  } else if (parsedValue == 70) {
    pop(context);
    showPopup(context, "Device is set to Idle Mode ✅", false, 7);

    showPopup(context, "Device is set to Idle Mode ✅", false, 7);
  } else if (parsedValue == 58) {
    pop(context);
    showPopup(context, "Password changed successfully ✅", false, 7);
  } else if (parsedValue == 83) {
    pop(context);
    showPopup(context, "Wrong Password.", false, 7);
  }
}

void pop(BuildContext context) {
  Navigator.of(context, rootNavigator: true).pop();
}

AppBar buildAppBar(BuildContext context) {
  return AppBar(
    toolbarHeight: 80,
    // backgroundColor: myTheme.colorScheme.primaryContainer,
    leading: IconButton(
      icon: const Icon(Icons.arrow_back, color: Colors.black),
      onPressed: () => pop(context),
    ),
    // title: Center(
    title: Image.asset(
      'assets/top.png',
      fit: BoxFit.contain,
      height: 53,
    ),
    // ),
    centerTitle: true,
  );
}

Widget buildNewRow(String str, BuildContext context,
    TextEditingController controller, int length) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 10.0),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          str,
          style: TextStyle(
            color: AllColor().txtColor,
            fontSize: 22.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        Container(
          height: 50.0,
          width: 150.0,
          decoration: BoxDecoration(
            color: myTheme.colorScheme.background,
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: controller,
                style: TextStyle(
                  color: AllColor().txtColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 18.0,
                ),
                keyboardType: TextInputType.number,
                maxLength: length,

                decoration: const InputDecoration(
                  counterText: '',
                  disabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 3.0),
                  ),
                ),
                onChanged: (text) {},
                // style: TextStyle(
                //   // color: myTheme.colorScheme.onPrimary,
                //   color: AllColor().txtColor,
                //   fontWeight: FontWeight.bold,
                //   fontSize: 20.0,
                // ),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
