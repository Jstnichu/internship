import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/colors.dart';
import 'package:Agromate/Values/functions.dart';

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  static List<String> contacts = ['+918143686030'];
  final ThemeData myTheme = AppTheme().myTheme;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Schedule',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontWeight: FontWeight.bold,
                    fontSize: 25.0,
                  ),
                ),
              ),
            ),
            Expanded(
              // child: Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 40),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'Enter time in Minutes: ',
                          style: TextStyle(
                              color: AllColor().txtColor,
                              fontSize: 22.0,
                              fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 15.0),
                        Container(
                          height: 50.0,
                          width: 95.0,
                          decoration: BoxDecoration(
                            color: myTheme.colorScheme.background,
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: TextField(
                                decoration: const InputDecoration(
                                  disabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Colors.black, width: 3.0),
                                  ),
                                ),

                                // maxLength: 3,
                                onSubmitted: (value) {
                                  showPopup(
                                      context,
                                      'Scheduling Motor for $value mins',
                                      true,
                                      0);
                                  SendSMS('mdur $value', contacts, context);
                                },
                                keyboardType: TextInputType.number,
                                style: TextStyle(
                                  color: AllColor().txtColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    buildElevatedButton('Back', 'back', context),
                  ],
                ),
              ),
              // ),
            ),
          ],
        ),
      ),
    );
  }
}
