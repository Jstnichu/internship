import 'package:flutter/material.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:Agromate/Values/functions.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeData myTheme = AppTheme().myTheme;

    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Settings',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontWeight: FontWeight.bold,
                    fontSize: 25.0,
                  ),
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const SizedBox(height: 25),
                      buildElevatedButton(
                          'Schedule Motor', "schedule", context),
                      const SizedBox(height: 25),
                      buildElevatedButton(
                          'Change Password', "changePwd", context),
                      const SizedBox(height: 25),
                      buildElevatedButton('Users', "user", context),
                      const SizedBox(height: 25),
                      buildElevatedButton('Mode', "Mode", context),
                      const SizedBox(height: 25),
                      buildElevatedButton('Language', "lang", context),
                      const SizedBox(height: 25),
                      buildElevatedButton(
                          'Agromate Number', "phoneNum", context),
                      const SizedBox(height: 25),
                      buildElevatedButton('About', "about", context),
                      const SizedBox(height: 25),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
