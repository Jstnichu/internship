// ignore_for_file: sized_box_for_whitespace

import 'package:Agromate/Values/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:telephony/telephony.dart';
import 'package:Agromate/Values/functions.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  static List<String> contacts = ['+918143686030'];
  static ThemeData myTheme = AppTheme().myTheme;
  static Telephony telephony = Telephony.instance;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: FToastBuilder(),
      theme: myTheme,
      home: Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
        floatingActionButton: FloatingActionButton(
          backgroundColor: myTheme.colorScheme.primaryContainer,
          onPressed: () {
            Navigator.pushNamed(context, AppRoutes.settingsPage);
          },
          child: const Icon(Icons.settings),
        ),
        backgroundColor: myTheme.colorScheme.background,
        appBar: AppBar(
          toolbarHeight: 80,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('Exit App',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          )),
                      content: const Text(
                        'Do you want to exit the App?',
                        style: TextStyle(fontSize: 16.0),
                      ),
                      actions: <Widget>[
                        TextButton(
                          child: const Text(
                            'No',
                            style: TextStyle(fontSize: 21.0),
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                        TextButton(
                          child: const Text(
                            'Yes',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 21.0,
                            ),
                          ),
                          onPressed: () {
                            SystemNavigator.pop();
                          },
                        ),
                      ],
                    );
                  },
                );
              }),
          // title: Center(
          title: Image.asset(
            'assets/top.png',
            fit: BoxFit.contain,
            height: 53,
          ),
          // ),
          centerTitle: true,
        ),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Home',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontSize: 25.0,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: 170,
                          height: 150,
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(
                                  color: Colors.green.shade900, width: 3.0),
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Column(
                                children: <Widget>[
                                  Text(
                                    'Pump count',
                                    style: TextStyle(
                                      fontSize: 21.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Icon(
                                    Icons
                                        .toggle_on, // replace with your desired icon
                                    size:
                                        30.0, // replace with your desired size
                                    color: Colors
                                        .black, // replace with your desired color
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    '0',
                                    style: TextStyle(
                                      fontSize: 20.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          width: 170,
                          height: 150,
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(
                                color: Colors.green.shade900,
                                width: 3.0,
                              ),
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Column(
                                children: <Widget>[
                                  Text(
                                    'Time Ran',
                                    style: TextStyle(
                                      fontSize: 21.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Icon(
                                    Icons
                                        .watch_later, // replace with your desired icon
                                    size:
                                        30.0, // replace with your desired size
                                    color: Colors
                                        .black, // replace with your desired color
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    '00:00',
                                    style: TextStyle(
                                      fontSize: 20.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const SizedBox(height: 25),
                    buildElevatedButton('Motor ON', "on", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Motor OFF', "off", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Get Status', "status", context),
                    const SizedBox(height: 35),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
