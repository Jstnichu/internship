import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/functions.dart';

class Users extends StatefulWidget {
  const Users({super.key});

  @override
  State<Users> createState() => _UsersState();
}

class _UsersState extends State<Users> {
  final ThemeData myTheme = AppTheme().myTheme;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Users',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontSize: 25.0,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    buildElevatedButton(
                      'Show Users',
                      "fetchUsers",
                      context,
                    ),
                    const SizedBox(height: 35),
                    buildElevatedButton('Add a User', "Users", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Delete a User', "DeleteUser", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Back', "back", context),
                    const SizedBox(height: 35),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
