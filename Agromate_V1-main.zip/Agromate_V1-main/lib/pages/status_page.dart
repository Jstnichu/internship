import 'package:Agromate/Values/functions.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:Agromate/Values/colors.dart';

class StatusPage extends StatefulWidget {
  final String stat;
  const StatusPage({Key? key, required this.stat}) : super(key: key);

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> {
  final pwrCont = TextEditingController();
  final motorCont = TextEditingController();
  final usrCont = TextEditingController();

  String pwrTxt = "N/A";
  String usrTxt = "N/A";

  @override
  void initState() {
    super.initState();
    pwrCont.text = pwrTxt;
    motorCont.text = widget.stat;
    usrCont.text = usrTxt;
  }

  // final String str;
  @override
  Widget build(BuildContext context) {
    ThemeData myTheme = AppTheme().myTheme;

    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 35.0),
              child: Container(
                height: 50.0,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2.0,
                    color: Colors.grey,
                  ),
                ),
                child: Center(
                  child: Text(
                    'Status',
                    style: TextStyle(
                      color: AllColor().txtColor,
                      fontSize: 25.0,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  buildRow("Power Status: ", pwrCont),
                  // const SizedBox(height: 30),
                  buildRow("Motor Status: ", motorCont),
                  buildRow("  User Status: ", usrCont),
                  const SizedBox(height: 30),
                  buildElevatedButton("Logs", 'logs', context),
                  const SizedBox(height: 30),
                  buildElevatedButton("Back", 'back', context),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget buildRow(String str, TextEditingController txtController) {
    ThemeData myTheme = AppTheme().myTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            str,
            style: TextStyle(
              color: AllColor().txtColor,
              fontSize: 22.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          Container(
            height: 50.0,
            width: 170.0,
            decoration: BoxDecoration(
              color: myTheme.colorScheme.background,
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: txtController,
                  decoration: const InputDecoration(
                    disabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 3.0),
                    ),
                  ),
                  onChanged: (text) {},
                  enabled: false,
                  style: TextStyle(
                    // color: myTheme.colorScheme.onPrimary,
                    color: AllColor().txtColor,
                    fontWeight: FontWeight.w500,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    pwrCont.dispose();
    motorCont.dispose();
    usrCont.dispose();

    super.dispose();
  }
}
