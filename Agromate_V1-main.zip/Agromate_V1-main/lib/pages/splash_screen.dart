import 'package:Agromate/Values/colors.dart';
import 'package:Agromate/Values/functions.dart';
import 'package:easy_splash_screen/easy_splash_screen.dart';
import 'package:flutter/material.dart';

import 'package:Agromate/Values/app_theme.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  SplashPageState createState() => SplashPageState();
}

class SplashPageState extends State<SplashPage> {
  ThemeData myTheme = AppTheme().myTheme;

  @override
  Widget build(BuildContext context) {
    return EasySplashScreen(
      gradientBackground: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.green.shade900,
          Colors.green.shade100,
          Colors.white,
          Colors.white,
          Colors.green.shade100,
          Colors.green.shade900,
        ],
      ),
      logo: Image.asset(
        'assets/top.png',
      ),
      logoWidth: 150,
      backgroundColor: myTheme.colorScheme.background,
      showLoader: true,
      loaderColor: AllColor().txtColor,
      loadingText: const Text("Initializing..."),
      navigator: getPhoneNumber(context),
      durationInSeconds: 4,
    );
  }
}
