// import 'package:Agromate/Values/functions.dart';
import 'package:Agromate/Values/functions.dart';
import 'package:Agromate/pages/bottomBar.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/app_theme.dart';

class NewHome extends StatefulWidget {
  const NewHome({super.key});
  static ThemeData myTheme = AppTheme().myTheme;

  @override
  State<NewHome> createState() => _NewHomeState();
}

class _NewHomeState extends State<NewHome> {
  final List<String> items = ['Front yard pump', 'Back yard pump', 'new pump'];
  final today = TextEditingController();
  final thisWeek = TextEditingController();
  final thisMonth = TextEditingController();
  final thisYear = TextEditingController();
  final runningStatus = TextEditingController();
  final lastTime = TextEditingController();
  String todayTxt = "01 HR 42 Min";
  String thisWeekTxt = "12 Hr 23 Min";
  String thisMonthTxt = "28 Days 5 Hr 42 Min";
  String thisYearTxt = "283 Days 11 Hr 15 Min";
  String runningStatusTxt = "OFF";
  String lastTimeTxt = "Last message received at 4:15 PM today";
  @override
  void initState() {
    super.initState();
    today.text = todayTxt;
    thisWeek.text = thisWeekTxt;
    thisMonth.text = thisMonthTxt;
    thisYear.text = thisYearTxt;
    runningStatus.text = runningStatusTxt;
    lastTime.text = lastTimeTxt;
  }

  String? selectedItem;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: NewHome.myTheme,
      home: Scaffold(
        backgroundColor: NewHome.myTheme.colorScheme.background,
        appBar: AppBar(
          toolbarHeight: 60,
          title: Image.asset(
            'assets/top.png',
            fit: BoxFit.contain,
            height: 60,
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 8.0,
              ),
              const SizedBox(
                height: 25.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(
                      Icons.devices,
                      size: 25,
                      color: Color(0xFF0E9278),
                    ),
                    SizedBox(width: 5),
                    Text(
                      'Device Selection',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 20.0,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 8.0,
              ),
              Container(
                width: 380,
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                decoration: BoxDecoration(
                  color: const Color(0xff0eaf4f2),
                  // border:
                  borderRadius: BorderRadius.circular(4.0),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    hint: const Text(
                      'Select Device',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.0,
                      ),
                    ),
                    value: selectedItem,
                    items: items.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedItem = newValue;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 8.0,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    Icons.watch_later_outlined,
                    size: 25,
                    color: Color(0xFF0E9278),
                  ), // Add this line
                  SizedBox(
                      width:
                          5), // Add this line to provide some space between the icon and the text
                  Text(
                    'Device Running Summary',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 8.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  buildCardRow('Today', today),
                  buildCardRow('This Week', thisWeek),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  buildCardRow('This Month', thisMonth),
                  buildCardRow('This year', thisYear),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Card(
                    color: const Color(0xff0eaf4f2),

                    // color: Color.fromARGB(1, 255, 255, 255),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6.0),
                      // side: BorderSide(color: Colors.green.shade900, width: 3.0),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(13.0),
                      child: Column(
                        children: <Widget>[
                          const Text(
                            'Motor Running Status',
                            style: TextStyle(
                              fontSize: 21.0,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(
                            width: 350.0,
                            height: 45.0,
                            child: TextField(
                              textAlign: TextAlign.center,
                              enabled: false,
                              controller: runningStatus,
                              style: TextStyle(
                                color: runningStatus.text == 'ON'
                                    ? const Color.fromARGB(255, 57, 122, 59)
                                    : const Color(0xff0c10000),
                                // color: Color(0xFF0C10000),
                                fontSize: 20.0,
                                fontWeight: FontWeight.w600,
                              ),
                              decoration: const InputDecoration(
                                counterText: '',
                                border: InputBorder.none,
                              ),
                              onChanged: (text) {},
                            ),
                          ),
                          SizedBox(
                            width: 350.0,
                            height: 20.0,
                            child: TextField(
                              textAlign: TextAlign.center,
                              enabled: false,
                              controller: lastTime,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 12.0,
                                fontWeight: FontWeight.w600,
                              ),
                              decoration: const InputDecoration(
                                counterText: '',
                                border: InputBorder.none,
                              ),
                              onChanged: (text) {},
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 8.0,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    Icons.bolt_outlined,
                    size: 25,
                    color: Color(0xFF0E9278),
                  ), // Add this line
                  SizedBox(
                      width:
                          5), // Add this line to provide some space between the icon and the text
                  Text(
                    'Device Operation',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 8.0,
              ),
              buildButton("Turn ON the Motor", "ON", const Color(0xff00E9278)),
              buildButton(
                  "Turn OFF the Motor", "OFF", const Color(0xff0B71515)),
              buildButton("Get motor Status", 'GET', const Color(0xff0D39E36)),
            ],
          ),
        ),
        bottomNavigationBar: BottomNavBar(),
      ),
    );
  }

  Card buildCardRow(String title1, TextEditingController controller) {
    return Card(
      color: const Color(0xff0eaf4f2),

      // color: Color.fromARGB(1, 255, 255, 255),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(6.0),
        // side: BorderSide(color: Colors.green.shade900, width: 3.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(11.0),
        child: Column(
          children: <Widget>[
            Text(
              title1,
              style: const TextStyle(
                fontSize: 21.0,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(
              height: 45.0,
              width: 165.0,
              child: TextField(
                textAlign: TextAlign.center,
                enabled: false,
                controller: controller,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                ),
                decoration: const InputDecoration(
                  counterText: '',
                  border: InputBorder.none,
                ),
                onChanged: (text) {},
              ),
            ),
          ],
        ),
      ),
    );
  }

  Padding buildButton(String text, String btText, Color btColor) {
    return Padding(
      padding:
          const EdgeInsets.only(top: 5.0, bottom: 5.0, left: 9.0, right: 9.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15.0),
          color: const Color(0xff0eaf4f2),
        ),
        width: MediaQuery.of(context).size.width,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment
                .spaceBetween, // This will place the text and the button on opposite sides of the row
            children: <Widget>[
              Text(
                text,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 23.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                height: 50,
                width: 90,
                child: ElevatedButton(
                  onPressed: () {
                    if (text == "ON") {
                      SendSMS('MOTOR ON', contacts, context);
                    } else if (text == "OFF") {
                      SendSMS('MOTOR OFF', contacts, context);
                    } else if (text == "GET") {
                      SendSMS('MOTOR STATUS', contacts, context);
                    }

                    // Handle button press here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: btColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: Text(btText,
                      style: const TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    today.dispose();
    thisWeek.dispose();
    thisMonth.dispose();
    thisYear.dispose();
    runningStatus.dispose();
    lastTime.dispose();

    super.dispose();
  }
}
