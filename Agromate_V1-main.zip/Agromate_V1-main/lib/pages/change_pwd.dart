import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/functions.dart';

class ChangePass extends StatefulWidget {
  const ChangePass({super.key});

  @override
  State<ChangePass> createState() => _ChangePassState();
}

class _ChangePassState extends State<ChangePass> {
  final ThemeData myTheme = AppTheme().myTheme;
  final TextEditingController controller_1 = TextEditingController();
  final TextEditingController controller_2 = TextEditingController();
  final TextEditingController controller_3 = TextEditingController();

  @override
  void dispose() {
    controller_1.dispose();
    controller_2.dispose();
    controller_3.dispose();
    super.dispose();
  }

  void handleSubmit() {
    String oldPass = controller_1.text;
    String newPass = controller_2.text;
    String confirmPass = controller_3.text;
    if (newPass != confirmPass) {
      showPopup(context, "Passwords do not match ❗", false, 5);
      return;
    } else if (newPass.length < 4) {
      showPopup(context, "Password too short ⚠️", false, 5);
      return;
    } else {
      SendSMS('PSW $oldPass $newPass $confirmPass', contacts, context);
      showPopup(context, "Changing Password", true, 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Change the Password',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontWeight: FontWeight.bold,
                    fontSize: 25.0,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 40),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      buildNewRow('Old Password: ', context, controller_1, 4),
                      buildNewRow('New Password: ', context, controller_2, 4),
                      buildNewRow(
                          'Confirm Password: ', context, controller_3, 4),
                      const SizedBox(
                        height: 30,
                      ),
                      buildElevatedButton(
                          'Change', 'registerUser', context, handleSubmit),
                      const SizedBox(height: 30),
                      buildElevatedButton('Back', 'back', context),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
