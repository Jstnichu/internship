// bottom_navigation_bar.dart
import 'package:Agromate/Values/app_routes.dart';
import 'package:flutter/material.dart';

class BottomNavBar extends StatefulWidget {
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    callSettings();
  }

  void callSettings() {
    Navigator.pushNamed(context, AppRoutes.settingsPage);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9.0, left: 9.0, right: 9.0),
      child: ClipRRect(
        clipBehavior: Clip.antiAlias,
        borderRadius: BorderRadius.circular(20.0),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Color(0xFFE5E5E5),
          selectedItemColor: Colors.black,
          selectedFontSize: 15.0,
          iconSize: 30.0,
          onTap: onTabTapped,
          currentIndex: _currentIndex,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(
                Icons.dashboard_outlined,
                color: Colors.black,
              ),
              label: 'Dashboard',
              activeIcon: Icon(
                Icons.dashboard,
                color: Colors.black,
              ),
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.access_time,
                color: Colors.black,
              ),
              activeIcon: Icon(
                Icons.access_time_filled,
                color: Colors.black,
              ),
              label: 'Schedule',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.assessment_outlined, color: Colors.black),
              label: 'Activity',
              activeIcon: Icon(
                Icons.assessment,
                color: Colors.black,
              ),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings_applications_outlined,
                  color: Colors.black),
              label: 'Settings',
              activeIcon: Icon(
                Icons.settings_applications_rounded,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
