import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/functions.dart';

class PhoneNum extends StatefulWidget {
  const PhoneNum({super.key});

  @override
  State<PhoneNum> createState() => _PhoneNumState();
}

class _PhoneNumState extends State<PhoneNum> {
  final ThemeData myTheme = AppTheme().myTheme;
  final TextEditingController controller_1 = TextEditingController();
  @override
  void dispose() {
    controller_1.dispose();
    super.dispose();
  }

  void handleSubmission() {
    String phone = controller_1.text;
    final hasOnlyDigits = RegExp(r'^\d+$').hasMatch(phone);

    if (!hasOnlyDigits || phone.length != 10) {
      showPopup(context, "Enter a valid Phone Number without the country code.",
          false, 3);
      return;
    } else if (phone.length == 10) {
      savePhoneNumber(phone, context, phone);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Agromate Phone Number',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontWeight: FontWeight.bold,
                    fontSize: 25.0,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 40),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      buildNewRow('Phone Number: ', context, controller_1, 10),
                      const SizedBox(
                        height: 30,
                      ),
                      buildElevatedButton(
                          'Save', 'next', context, handleSubmission),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
