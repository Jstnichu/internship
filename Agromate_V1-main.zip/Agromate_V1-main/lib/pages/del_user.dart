import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/functions.dart';

class DeleteUser extends StatefulWidget {
  const DeleteUser({super.key});

  @override
  State<DeleteUser> createState() => _DeleteUserState();
}

class _DeleteUserState extends State<DeleteUser> {
  final ThemeData myTheme = AppTheme().myTheme;
  final TextEditingController controller_1 = TextEditingController();
  final TextEditingController controller_2 = TextEditingController();
  @override
  void dispose() {
    controller_1.dispose();
    controller_2.dispose();
    super.dispose();
  }

  void handleSubmitDel(String val) {
    String phone = controller_1.text;
    String password = controller_2.text;
    SendSMS('DEL $phone $password', contacts, context);
    showPopup(context, "Deleting $phone", true, 0);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Delete a User',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontWeight: FontWeight.bold,
                    fontSize: 25.0,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 40),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      buildNewRow('Phone Number: ', context, controller_1, 10),
                      buildNewRow('Enter Password: ', context, controller_2, 4),
                      const SizedBox(
                        height: 30,
                      ),
                      buildElevatedButton(
                          'Delete', 'registerUser', context, handleSubmitDel),
                      const SizedBox(height: 30),
                      buildElevatedButton(
                          'Back', 'back', context, handleSubmitDel),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
