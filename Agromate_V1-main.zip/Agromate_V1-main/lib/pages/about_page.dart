import 'package:Agromate/Values/functions.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/app_theme.dart';
import 'package:Agromate/Values/colors.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  final serial = TextEditingController();
  final device = TextEditingController();
  final apk = TextEditingController();

  String serialTxt = "E-PLUS";
  String deviceTxt = "AGROMATE";
  String apkTxt = "V1.0";
  @override
  void initState() {
    super.initState();
    serial.text = serialTxt;
    device.text = deviceTxt;
    apk.text = apkTxt;
  }

  @override
  Widget build(BuildContext context) {
    ThemeData myTheme = AppTheme().myTheme;

    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 35.0),
              child: Container(
                height: 50.0,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2.0,
                    color: Colors.grey,
                  ),
                ),
                child: Center(
                  child: Text(
                    'About',
                    style: TextStyle(
                      color: AllColor().txtColor,
                      fontSize: 25.0,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  buildRow("Serial Number:", serial),
                  // const SizedBox(height: 30),
                  buildRow("  Device Name:", device),
                  buildRow("  APK Version:", apk),
                  const SizedBox(height: 30),
                  buildElevatedButton("Back", 'back', context),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    serial.dispose();
    device.dispose();
    apk.dispose();

    super.dispose();
  }

  Widget buildRow(String str, TextEditingController txtController) {
    ThemeData myTheme = AppTheme().myTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(
            str,
            style: TextStyle(
              color: AllColor().txtColor,
              fontSize: 22.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          Container(
            height: 50.0,
            width: 170.0,
            decoration: BoxDecoration(
              color: myTheme.colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: txtController,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                  ),
                  enabled: false,
                  style: TextStyle(
                    color: AllColor().txtColor,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
