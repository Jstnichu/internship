import 'package:Agromate/Values/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:Agromate/Values/functions.dart';

class Mode extends StatefulWidget {
  const Mode({super.key});

  @override
  State<Mode> createState() => _ModeState();
}

class _ModeState extends State<Mode> {
  final ThemeData myTheme = AppTheme().myTheme;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: myTheme,
      home: Scaffold(
        backgroundColor: myTheme.colorScheme.background,
        appBar: buildAppBar(context),
        body: Column(
          children: <Widget>[
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 2.0,
                  color: Colors.grey,
                ),
              ),
              child: const Center(
                child: Text(
                  'Set Mode',
                  style: TextStyle(
                    color: Color.fromARGB(255, 0, 72, 4),
                    fontSize: 25.0,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    buildElevatedButton(
                        'Intelligent Mode', "smartMode", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Auto Mode', "autoMode", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Idle Mode', "idleMode", context),
                    const SizedBox(height: 35),
                    buildElevatedButton('Back', "back", context),
                    const SizedBox(height: 35),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
