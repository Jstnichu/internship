# Agromate App

This is a Flutter application designed to communicate with Agromate devices via SMS.

## About
Agromate is a device useful for controlling agricultural pumps over a call or an SMS. This app is designed to simplify the process of interacting with Agromate.
